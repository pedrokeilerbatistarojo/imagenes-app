/** @type {import('tailwindcss').Config} */
export default {
  content: ["views/pages/*.ejs"],
  theme: {
    extend: {},
  },
  plugins: [],
}

